from django.shortcuts import render, HttpResponse
import json

with open('MainApp/templates/country-by-abbreviation.json') as f:
    countries_list = json.load(f)


# Create your views here.

def main(request):
    return render(request, 'index.html')


def func_country(request, country_name):
    context = {}
    for country in countries_list:
        if country["country"] == country_name:
            context["country"] = country
            return render(request, 'country.html', context)

    return HttpResponse(f"Страна с названием {country_name} не найдена")


def func_countries(request):
    # countries_list = []
    context = {
        "countries": countries_list
    }
    return render(request, 'countries.html', context)


def func_languages(request):
    languages_set = set()
    for country in countries_list:
        for language in country["languages"]:
            languages_set.add(language)
    languages_list = list(languages_set)
    languages_list.sort()
    context = {
        "languages_list": languages_list
    }
    return render(request, 'languages.html', context)

def func_countries_by_language(request, language_name):
    countries_list_by_language = []
    for country in countries_list:
        if language_name in country["languages"]:
            countries_list_by_language.append(country["country"])
    countries_list_by_language.sort()
    context = {
        "language": language_name,
        "countries_list_by_language": countries_list_by_language
    }
    return render(request, 'countriesbylanguage.html', context)




